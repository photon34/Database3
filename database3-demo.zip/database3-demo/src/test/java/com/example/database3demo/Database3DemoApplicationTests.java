package com.example.database3demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Database3DemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
