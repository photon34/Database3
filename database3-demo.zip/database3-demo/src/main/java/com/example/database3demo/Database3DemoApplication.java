package com.example.database3demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Database3DemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(Database3DemoApplication.class, args);
	}

}
